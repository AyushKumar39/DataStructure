package string;

import java.util.Scanner;

public class MaxMinOccuranceCharacter {
    public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the String :  ");
        String x=sc.nextLine();
        System.out.println();
    }
}
