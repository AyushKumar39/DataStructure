import java.lang.*;
import java.util.Scanner;

class Weekly
{
     public static void main(String []args)
     {
         int day;
         System.out.println("enter the number");
         Scanner sc=new Scanner(System.in);

         day=sc.nextInt();

         switch(day)
         {
              case 1:
              {
                System.out.println("monday");
                break;
              }
              case 2:
              {
                   System.out.println("tuesday");
                   break;
              }
              case 3:
              {
                   System.out.println("wednesday");
                   break;
              }
              case 4:
              {
                   System.out.println("thrusday");
                   break;
              }
              case 5:
              {
                   System.out.println("friday");
                   break;
              }
              case 6:
              {
                   System.out.println("satursday");
                   break;
              }
              case 7:
              {
                   System.out.println("sunday");
              }
              default:
              {
                   System.out.println("Invalid number");
              }
         }
     }
}
