public class incOrder {
//    public static int incOrder(int n){
//        if(n==0){
//            System.out.print(n);
//            return 0;
//        }
//        incOrder(Integer.parseInt(n-1 + "" ));
//        System.out.print(n);
//        return 0 ;
//    }
//    public static void main(String args[]){
//      int n=10;
//        incOrder(n );
//    }

}
