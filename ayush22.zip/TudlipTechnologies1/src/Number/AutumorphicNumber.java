package Number;

import java.util.Scanner;

public class AutumorphicNumber {
    public static void main(String args[]){
        System.out.println("Enter the number : ");
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        if(isAutomorphic(n)){
            System.out.println("Automorphic");
        }
        else{
            System.out.println("Not Automorphic");
        }
    }
    static boolean  isAutomorphic(int n){
        int square=n*n;
        while(n>0){
            if(n%10!=square%10)
                return false;
                n=n/10;
                square=square/10;
        }
        return true;
    }
}
