package Number;

import java.util.Scanner;

public class ReverseNumber {
    public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the Number : ");
        int number=sc.nextInt();
        int reverse=0;
        while(number!=0){
            int remainder=number%10;
            reverse=reverse * 10+remainder;
            number=number/10;
        }
        System.out.println("the reverse Number is " +reverse);
    }
}
