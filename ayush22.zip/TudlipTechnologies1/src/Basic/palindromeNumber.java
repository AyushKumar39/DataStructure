package Basic;

import java.util.Scanner;

public class palindromeNumber {
    public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the Number :");
        int n=sc.nextInt();
        int remainder,sum=0,temp;
        temp=n;
        while(n>0){
            remainder=n%10;
            sum=(sum*10)+remainder;
            n=n/10;
        }
        if(temp==sum){
            System.out.print( sum+" palindrome number");
        }else{
            System.out.println( sum+" not palindrome");
        }
    }
}
