package Basic;

import java.util.Scanner;

public class primeNumber {
    public static void main(String[] args ){

        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the Prime Number : ");
        int n = sc.nextInt();
        if(n%2==0){
            System.out.println( n +" is not A Prime Number");
        }
        else{
            System.out.println( n +" is  A Prime Number");
        }
    }
}
