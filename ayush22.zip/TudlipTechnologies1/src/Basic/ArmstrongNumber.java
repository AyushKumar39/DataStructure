package Basic;

import java.sql.SQLOutput;
import java.util.Scanner;

public class ArmstrongNumber {
    static boolean isArmStrong(int n){
        int temp,digits=0,last=0,sum=0;
        temp=n;
        while(temp>0){
            temp=temp/10;
            digits++;
        }
        temp=n;
        while(temp>0){
            last=temp%10;
            sum +=(Math.pow(last,digits));
            temp=temp/10;
        }
        if(n==sum){
            return true;
        }
        else{
            return false;
        }
    }
    public static void  main(String []args){

        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the number : ");
         int num=sc.nextInt();
         if(isArmStrong(num)){
             System.out.println("ArmStrong Number :" +num);
             System.out.println("true");
         }else{
             System.out.println("false");
         }
    }
}
