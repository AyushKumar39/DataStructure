import java.util.Scanner;

public class FoobarPrint {
    public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the number");
        int num=sc.nextInt();
        if(num%43==0) {
            System.out.println("foo");
        }if(num%73==0){
            System.out.println("bar");
        }if(num%43==0 && num%73==0){
            System.out.println("Foobar");
        }
    }
}
