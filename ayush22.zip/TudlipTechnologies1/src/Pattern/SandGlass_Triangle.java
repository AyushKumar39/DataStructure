package Pattern;

import java.util.Scanner;

public class SandGlass_Triangle {
    public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the Number : ");
        int row =sc.nextInt();
        for(int i=0;i<=row-1;i++) {
            for (int j = 0; j < i; j++) {
                System.out.print(" ");
            }
            for (int k = i; k <= row - 1; k++) {
                System.out.print("*" + " ");
            }
            System.out.println("");
        }
            for(int j=row-1;j>=0;j--){
                for(int k=0;k<j;k++){
                    System.out.print(" ");
                }
                for(int k=j;k<=row-1;k++){
                    System.out.print("*" +" ");
                }
                System.out.println("");
            }
        sc.close();
    }
}
