package Pattern;

public class ReversePyramind {
    public static void main(String []args){
        int row=6;
        for(int i=0;i<=row-1;i++){
            for(int j=0;j<=i;j++){
                System.out.print(" ");
            }
            for(int j=0;j<=row-1-i;j++){
                System.out.print("*" +" ");
            }
            System.out.println();
        }
    }
}
