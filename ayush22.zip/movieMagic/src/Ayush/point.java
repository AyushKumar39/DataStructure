package Ayush;

    class Point{
    public int x;
    public int y;
    public Point(int x,int y){
        this.x=x;
        this.y=y;
    }
    public int getX(){
       return x;
    }
    public int getY() {
        return y;
    }
    public void setLocation(int x,int y){
         this.x=x;
         this.y=y;
    }
    public void move(int x,int y){
      this.x=this.x+x;
      this.y=this.y+y;
    }
    public String toString(){
        return "Point :" +" " +x +" " +y;
    }

    }
class Point1{
        Point p=new Point(5,4);

}