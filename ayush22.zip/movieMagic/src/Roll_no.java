 class Student {
    static int lastRollNo;
    int rollNo;
    public Student(){
        lastRollNo++;
        rollNo=lastRollNo;
    }
    public void display(){
        lastRollNo++;
        rollNo=lastRollNo;
     }
}
class Student1{
    public static void main(String []args){
        Student s1,s2,s3,s4;
        s1=new Student();
        s2=new Student();
        s3=new Student();
        s4= new Student();
        s1.display();
        s2.display();
        s3.display();
        s4.display();
    }
}
