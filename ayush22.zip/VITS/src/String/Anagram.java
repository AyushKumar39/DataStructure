package String;

import java.util.Arrays;
import java.util.Scanner;

public class Anagram {
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the String :");
        String str=sc.nextLine();
        System.out.println("Enter the 2nd String :");
        String str2=sc.nextLine();
         str=str.toLowerCase();
         str2=str2.toLowerCase();
         if(str.length() !=str2.length()){
             System.out.println("Both the String are Not Anagram");
         }else {
             char[] string = str.toCharArray();
             char[] string1 = str2.toCharArray();
             Arrays.sort(string);
             Arrays.sort(string1);

             if (Arrays.equals(string, string1)){
                 System.out.println("Both the String are anagram :");
             }else{
                 System.out.println("Both the String are not Anagram");
             }
         }
    }
}
