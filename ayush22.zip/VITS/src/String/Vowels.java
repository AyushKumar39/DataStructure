package String;

import java.util.Scanner;

public class Vowels {
    public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the String : ");
        String vowels=sc.nextLine();
        vowels=vowels.toLowerCase();
        int vCount=0;
        int cCount=0;
        for(int i=0;i<vowels.length();i++){
            if(vowels.charAt(i)=='a' || vowels.charAt(i)=='e'
            || vowels.charAt(i) =='i' ||vowels.charAt(i)=='o'||
            vowels.charAt(i)=='u'){
                vCount++;
            }else if(vowels.charAt(i)>='a' && vowels.charAt(i)<='z'){
               cCount++;
            }
        }
        System.out.println("number of vowels "  +vCount);
        System.out.println("number of constant "  +cCount);
    }
}
