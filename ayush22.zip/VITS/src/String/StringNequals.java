package String;

import java.util.Scanner;

public class StringNequals {
    public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the character :");
        String str=sc.nextLine();
        int length=str.length();
        System.out.println("Enter the N :");
        int n=sc.nextInt();

        String[] equalStr=new String[n];
        int chars=length/n;
        int temp=0;

        if(length%n!=0){
            System.out.println("Sorry this string cannot be divided into " +n +" equals parts");
        }else{
            for(int i=0;i<length; i=i+chars){
                String part=str.substring(i,i+chars);
                equalStr[temp]=part;
                temp++;
            }
            System.out.println(n +"equals part of given string are :");
            for(int i=0;i<equalStr.length;i++){
                System.out.println(equalStr[i]);
            }
        }
    }
}
