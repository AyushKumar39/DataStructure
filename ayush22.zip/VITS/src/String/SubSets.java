package String;

import java.util.Scanner;

public class SubSets {
    public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the String :");
        String str=sc.nextLine();
        int length=str.length();
        int temp=0;
        int count=0;
        String arr[]=new String [length*(length+1)/2];
        for(int i=0;i<length;i++){
            for(int j=i;j<length;j++){
                arr[temp]=str.substring(i,j+1);
                temp++;
                count++;
            }
        }
        for(int i=0;i< arr.length;i++){
            System.out.println(arr[i]);
        }
        System.out.println("total number of subString are : "+count);
    }
}
