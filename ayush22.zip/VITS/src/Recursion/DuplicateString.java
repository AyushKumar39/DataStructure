package Recursion;

public class DuplicateString {
    public static void Duplicatestring(String str,int idx,StringBuilder newStr,boolean map[]){
    if(idx==str.length()){
        System.out.println(newStr);
        return;
    }
    char currChar=str.charAt(idx);
    if(map[currChar-'a']==true){
        Duplicatestring(str,idx+1,newStr,map);
    }
    else{
        map[currChar-'a']=true;
        Duplicatestring(str,idx+1,newStr.append(currChar),map);
    }
    }
    public static void main(String []args){

    }
}
