package Recursion;

public class FabonacciNum {
    public static int fab(int n){
        if(n==0 || n==1){
            return n;
        }
        int nm1=fab(n-1);
        int nm2=fab(n-2);
        int fn=nm1+nm2;
        return fn;
    }
    public static void main(String []args){
        int n=10;
        System.out.println(fab(n));

    }
}
