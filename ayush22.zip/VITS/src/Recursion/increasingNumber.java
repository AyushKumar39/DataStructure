package Recursion;

public class increasingNumber {

    public static void DecNum(int n){
      if(n==0){
           return;
      }
        System.out.println(1 +" ");
        DecNum(n-1);
    }
    public static void main(String []args){
          int n=10;
        DecNum(n);
    }
}
