package Recursion;

import java.util.ArrayList;
import java.util.List;

public class FirstOccurance {
    public static void firstoccurance(int arr[], int key, int i, List<Integer> indices){
        if(i==arr.length){
            return;
        }

            if (arr[i] == key) {
                indices.add(i);
            }



        firstoccurance(arr,key,i+1,indices);
    }
    public static void main(String []args){
        int arr[]={8,3,6,9,5,3,4,5,3,5};
        int key=5;
        List<Integer> indices=new ArrayList<>();
        firstoccurance(arr, key, 0,indices);

        if (!indices.isEmpty()) {
            System.out.println("First occurrence of " + key + " is at index: " + indices);
        } else {
            System.out.println(key + " not found in the array.");
        }
    }
}
