package Recursion;

import org.w3c.dom.Node;


public class LinkedList {
    public static class node{
       int data;
       node next;
       public node(int data){
           this.data=data;
           this.next=next;
       }
    }
    public static node head;
    public static node tail;
    public static int size;
    public void addFirst(int data){
        node newNode=new node(data);
        size++;
        if(head==null){
        head=tail= newNode;
        }
        newNode.next=head;
        head=newNode;
    }
    public void addLast(int data){
        node newNode=new node(data);
        size++;
        if(head== null){
            head=tail=newNode;
            return;
        }
        tail.next=newNode;
        tail=newNode;
    }
    public void print(){
        node temp=head;
        while(temp!=null){
            System.out.println(temp.data +" ");
            temp=temp.next;
        }
        System.out.println();
        if(head==null){
            System.out.println("LL is empty");
            return;
        }
    }
    public void Addmiddle(int idx,int data){
        node newNode=new node(data);
        if(idx==0){
            addFirst(data);
            return;
        }
        node temp=head;
        int i=0;
        while(i<idx-1){
            temp=temp.next;
            i++;
        }
        newNode.next=temp.next;
        temp.next=newNode;
    }
    public static void main(String[]args){
    LinkedList ll=new LinkedList();
    ll.addFirst(1);
    ll.addFirst(2);
    ll.addFirst(3);
    ll.addFirst(4);
    ll.addLast(2);
    ll.addLast(3);
    ll.addLast(6);
    ll.addLast(9);
    ll.Addmiddle(2,5);
    ll.addLast(2);
        ll.print();
        System.out.println("size of linked list " +ll.size);

    }
}
