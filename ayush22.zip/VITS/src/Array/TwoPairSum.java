package Array;

public class TwoPairSum {
    public static boolean PairSum(int arr[], int target){
        for(int i=0;i<arr.length;i++){
            for(int j=i+1;j<arr.length;j++){
                if(arr[i]+arr[j]==target) {
                    return true;
                }

            }
        }
            return false;
    }
    public static void main(String []args){
        int arr[]={1,3,4,2,-2};
        int target=21;
        if (PairSum(arr, target))
            System.out.println("true");
        else
            System.out.println("false");
    }
}
