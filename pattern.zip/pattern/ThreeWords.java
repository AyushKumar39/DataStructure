package pattern;

import java.util.Scanner;

public class ThreeWords {
    public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the Number : ");
        int lines=sc.nextInt();
        int j;
        for(int i=1;i<=lines;i++){
            for( j=1;j<=lines;j++) {
                if (i == j)
                    System.out.print("*");

                else
                    System.out.print("0");
            }
                j--;
                System.out.print("*");

                while (j>=1){
                    if(i==j)
                        System.out.print("*");
                    else
                        System.out.print("0");
                    j--;
                }
                System.out.println("");
            }

    }
}
